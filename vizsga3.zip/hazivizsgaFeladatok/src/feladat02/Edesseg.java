package feladat02;

public class Edesseg {
	
	private String megnevezes;
	private double egysegar;
	private int darabszam;

	
	
	public Edesseg(String megnevezes, double egysegar, int darabszam) {
		super();
		this.megnevezes = megnevezes;
		this.egysegar = egysegar;
		this.darabszam = darabszam;
	}



	public int keszletErtek() {
		
		return darabszam ;

		

		
	}
	
}





