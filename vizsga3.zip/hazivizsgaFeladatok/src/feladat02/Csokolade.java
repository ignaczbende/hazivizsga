package feladat02;

public class Csokolade {

	public Csokolade(String string, int i, int j, int k) {
		// TODO Auto-generated constructor stub
	}

	public class csokolade extends Edesseg {
	    private int kakaotartalom;

	    public csokolade(String megnevezes, int egysegAr, int darabszam, int kakaotartalom) {
	        super(megnevezes, egysegAr, darabszam);
	        this.kakaotartalom = kakaotartalom;
	    }

	    public int getKakaotartalom() {
	        return kakaotartalom;
	    }

	    @Override
	    public String toString() {
	        return super.toString() + ", Kakaótartalom: " + kakaotartalom;
	    }
	}

}
