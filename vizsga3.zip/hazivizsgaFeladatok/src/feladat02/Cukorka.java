package feladat02;

public class Cukorka {
	public class cukorka extends Edesseg {
	    private boolean toltott;

	    public cukorka(String megnevezes, int egysegAr, int darabszam, boolean toltott) {
	        super(megnevezes, egysegAr, darabszam);
	        this.toltott = toltott;
	    }

	    public boolean isToltott() {
	        return toltott;
	    }

	    @Override
	    public String toString() {
	        return super.toString() + ", Töltött: " + (toltott ? "Igen" : "Nem");
	    }
	}
}
