package feladat02;

import static org.junit.Assert.assertEquals;

import feladat02.Csokolade.csokolade;
import feladat02.Cukorka.cukorka;

public class Foprogram {

		
		// ide kerüljön a tömb feltöltése majd a kiíratás:
		
	public static void main(String[] args) {
	    Edesseg[] edessegTomb = new Edesseg[3];
	    edessegTomb[0] = new Edesseg("Csoki", 300, 5);
	    edessegTomb[1] = new csokolade("Mogyorós csoki", 400, 8, 50);
	    edessegTomb[2] = new cukorka("Mentol cukorka", 100, 10, true);

	    for (Edesseg edesseg : edessegTomb) {
	        System.out.println(edesseg);
	        System.out.println("Készletérték: " + edesseg.keszletErtek());
	        System.out.println("Típus: " + edesseg.getClass().getSimpleName());
	        System.out.println();
	        
	        
	        class CsokoladeTest {

	            @Test
	            public void testCsokoladeToString() {
	                Csokolade csokolade = new Csokolade("Mogyorós csoki", 400, 8, 50);
	                
	                String expected = "Megnevezés: Mogyorós csoki, Egységár: 400, Darabszám: 8, Kakaótartalom: 50";
	                String actual = csokolade.toString();
	                
	                assertEquals(expected, actual);
	            }
	        }
	        
	            
	    }
	}  

	        
	    
	

	    





		    
		    
	
		    
		    
		

	

