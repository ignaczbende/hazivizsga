package feladat04;

public class Rendeles {

	private String szallitoiAzonosito;
	private String megnevezes;
	private int mennyiseg;
	private int osszertek;
	private boolean surgos;



	

    public Rendeles(String szallitoAzonosito, String teteleMegnevezes, int mennyiseg, int d, boolean surgos) {
    this.szallitoiAzonosito = szallitoAzonosito;
    this.megnevezes = teteleMegnevezes;
    this.mennyiseg = mennyiseg;
    this.osszertek = d;
    this.surgos = surgos;
    }

    public Rendeles(String[] csvSor) {
    }
}
	
	

	
public String getSzallitoAzonosito() {
	// TODO Auto-generated method stub
	return null;
}



public String getTeteleMegnevezes() {
	// TODO Auto-generated method stub
	return null;
}



public String getMennyiseg() {
	// TODO Auto-generated method stub
	return null;
}



public String getOsszertek() {
	// TODO Auto-generated method stub
	return null;
}



public String isSurgos() {
	// TODO Auto-generated method stub
	return null;
}
}

	

