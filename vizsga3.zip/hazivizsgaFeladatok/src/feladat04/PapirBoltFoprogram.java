package feladat04;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

public class PapirBoltFoprogram{

	public static void main(String[] args) throws IOException {
		
		List<Rendeles> rendelesek = new ArrayList<Rendeles>();
		FajlKezeles fajlObj = new FajlKezeles();
		
		System.out.println("Fájl beolvasva. Hibás tételek száma: "+fajlObj.beolvas(rendelesek,"SzallitoiRendelesek.csv"));{
	
			
		    for (int i = rendelesek.size() - 1; i >= 0; i--) {
		        Rendeles rendeles = rendelesek.get(i);
		        System.out.println("Szállítólevél azonosító: " + rendeles.getSzallitoAzonosito());
		        System.out.println("Tétel megnevezés: " + rendeles.getTeteleMegnevezes());
		        System.out.println("Mennyiség: " + rendeles.getMennyiseg());
		        System.out.println("Összérték: " + rendeles.getOsszertek());
		        System.out.println("Sürgős szállítás: " + rendeles.isSurgos());
		        System.out.println();
		        
		        
		        Rendeles ujRendeles1 = new Rendeles("S00003", "Zebra golyóstoll", 100, 22500, false);
		        Rendeles ujRendeles2 = new Rendeles("S00005", "kétlyukú hegyező", 35, 9500, true);
		        
		        rendelesek.add(ujRendeles1);
		        rendelesek.add(ujRendeles2);
		        
		    }
		}

		
	}
}


	


