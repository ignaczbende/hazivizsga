package feladat03;

public class parkolo {

	public void addRendszam(String rendszam) {
		// TODO Auto-generated method stub
		FoprogramRendszamok.add("ABC-123");
		FoprogramRendszamok.add("DEF-456");
	}

	public static String getRendszamokSzama() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getBehajtottAutokSzama() {
		// TODO Auto-generated method stub
		return null;
	}

	public static String getNemBehajtottAutokSzama() {
		// TODO Auto-generated method stub
		return null;
	}

}
