package feladat4Teszt;

import static org.junit.jupiter.api.Assertions.assertTrue;


import org.junit.jupiter.api.Test;

import feladat04.FajlKezeles;


class FajlKezelesTeszt {

	@Test
	void ellenorizTeszt() {
		
		FajlKezeles fajlObj = new FajlKezeles();
		String[] tesztCsvSor = {"S00008","toll","100","4000","1"};
		
		assertTrue(fajlObj.ellenoriz(tesztCsvSor));{
		
		
		boolean ellenoriz(String[] csvSor) {
		    
		    if (csvSor.length != 5) {
		        return false; 
		    }

		    String szallitoAzonosito = csvSor[0];
		    String teteleMegnevezes = csvSor[1];
		    int mennyiseg = Integer.parseInt(csvSor[2]);
		    double osszertek = Double.parseDouble(csvSor[3]);
		    boolean surgos = Integer.parseInt(csvSor[4]) == 1;

		    
		    if (!szallitoAzonosito.startsWith("S") || szallitoAzonosito.length() != 6) {
		        return false; 
		    }

		    

		    return true; 
		
	}

}
