package feladat01;

public class JelszoErosseg {

	public static void main(String[] args) {
		
		String[] jelszavak = {"Password34", "Valami999", "Ezjolesz77", "erosJelszo76"};
				
		System.out.println("A tömbben lévő érvényes jelszavak száma: "+ervenyes(jelszavak));
		
	}
	

	private static int ervenyes(String[] jelszavak) {
		int ervenyesJelszavakSzama = 0;
		

		// itt kell megvalósítani a jelszavakat kiíró és az érvényeseket összeszámoló ciklust
		
		
		
		
	        for (String jelszo : jelszavak) {
	            boolean ervenyes = ellenorzes(jelszo);

	            if (ervenyes) {
	                System.out.println(jelszo + " érvényes");
	                ervenyesJelszavakSzama++;
	            } else {
	                System.out.println(jelszo + " érvénytelen");
	            }
	        }

	        System.out.println("Érvényes jelszavak száma: " + ervenyesJelszavakSzama);
			return ervenyesJelszavakSzama;
			
			
	    }

	    public static boolean ervenyes(String jelszo) {
	        if (jelszo.length() != 10) {
	            return false;
	        }

	        if (!Character.isUpperCase(jelszo.charAt(0))) {
	            return false;
	        }

	        for (int i = 1; i <= 8; i++) {
	            if (!Character.isLowerCase(jelszo.charAt(i))) {
	                return false;
	            }
	        }

	        for (int i = 8; i < 10; i++) {
	            if (!Character.isDigit(jelszo.charAt(i))) {
	            return false;
	        }
	        }
	        return true;
	    }
	

	
	public static boolean ellenorzes(String jelszo) {
		
		if (jelszo.length() == 10
				&& Character.isLowerCase(jelszo.charAt(0)) 
				&& jelszo.substring(2,8).toLowerCase().equals(jelszo.substring(2,8))
				&& Character.isDigit(jelszo.charAt(8))
				&& Character.isDigit(jelszo.charAt(9))				) {
			
			return true;
			
		}
		
		return false;
	}

}
